package Scenerious;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.WebDriverWait;


import Helper.SelectBrowser;
import TestPages.ChatPage;
import TestPages.LoginPage;
import TestPages.SolutionCenter;


public class TestCallMePage {

	WebDriver driver;
	LoginPage login;
	SolutionCenter solcent;
	SelectBrowser selBrows;
	ChatPage  chatPage;

	@BeforeMethod
	public void beforeTest() {
		System.out.println("Before Test method");
		
		//navigates https://www.hepsiburada.com/cozummerkezi
		driver = SelectBrowser.startBrowser("https://www.hepsiburada.com/cozummerkezi");
		
		System.out.println("Before test  " + driver.getTitle());

	}

	@AfterMethod
	public void afterTest(ITestResult result) {

		System.out.println("After Test method");

		// using ITestResult.FAILURE is equals to result.getStatus then it enter into if
		// condition
		if (ITestResult.FAILURE == result.getStatus()) {
			try {
				// To create reference of TakesScreenshot
				TakesScreenshot screenshot = (TakesScreenshot) driver;
				// Call method to capture screenshot
				File src = screenshot.getScreenshotAs(OutputType.FILE);
				Date date = new Date(System.currentTimeMillis());
				SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy_HHmmss");
				System.out.println(formatter.format(date));
				
				FileUtils.copyFile(src, new File("test-output\\ScreenShots\\" +formatter.format(date)+"__"+ result.getName() + ".png"));
				System.out.println("Successfully captured a screenshot");
			} catch (Exception e) {
				System.out.println("Exception while taking screenshot " + e.getMessage());
			}
		}
		driver.quit();
	}

	@Test
	public void test1() throws InterruptedException {

		//value is true if the title of page is same with title of Solution Center
		assertEquals(driver.getTitle(), SolutionCenter.getTitleOfSolutionCenter());
		
		// creates an object of SolutionCenter
		solcent = new SolutionCenter(driver);	
		
		clickOn(driver, solcent.getAboutMyOrder(), 20);	

		assertEquals(driver.getTitle(), LoginPage.getTitleOfLoginPage());
		
		//creates an object of LoginPage and clicks Username
		login = new LoginPage(driver);
		
		clickOn(driver, login.getUserName(), 20);
	
		//types dennemme17@gmail.com to Username textfield and clicks on the login button
		login.setUsername("murratt17@gmail.com");
		clickOn(driver, login.getBtnLogin(), 20);

		//clicks on the password textfield and types Murratt_01 and clicks login button
		clickOn(driver, login.getPassword(), 20);
		login.setPassword("murratt_01");
		clickOn(driver, login.getBtnLogin2(), 20);
		
		//click the first order
		clickOn(driver, solcent.getMyFirstOrder(), 20);	
		
		//check if the title is ��z�m Merkezi
		assertEquals(driver.getTitle(), SolutionCenter.getTitleOfSolutionCenter());
		
		//create a new ChatPage Object
		chatPage = new ChatPage(driver);
				
		//click on "Farkl� Bir Konuda Sorum Var
		clickOn(driver, chatPage.getQuestionAboutDifferentTopic(), 20);	
				
		//check if the title of chat page is "��z�m Merkezi"
		checkIfPagesTrue(driver, chatPage.getSolutionCenterTitle() , 20,"��z�m Merkezi");
		
		//click on "�r�n Bilgisi"
		clickOn(driver, chatPage.getProductInfo(), 20);	

		//click on "�r�n Orjinal midir"
		clickOn(driver, chatPage.getIsProductOriginal(), 20);	
			
		//check if the title of chat page is "�r�nler Orjinal Midir?"
		checkIfPagesTrue(driver, chatPage.getAreProductsOriginial() , 20,"�r�nler orijinal midir?");
			
		//click "Beni Aray�n"
		clickOn(driver, chatPage.getBtnCallMe(), 20);	
				
		//check if the title of chat page is "Arama Talebi Olustur"
		checkIfPagesTrue(driver, chatPage.getCallRequest() , 20,"Arama talebi olu�tur");
		
		//click Gonder
		clickOn(driver, chatPage.getBtnGonder(), 20);	
		
		//check if the title of chat page  is "Talebiniz Olusturuldu"
		checkIfPagesTrue(driver, chatPage.getMainText() , 20,"Talebiniz olu�turuldu");
	
	}

    //waits until element is clickable and clicks on it
	public void clickOn(WebDriver driver1, WebElement element, int timeout) throws InterruptedException {
		new WebDriverWait(driver1, Duration.ofSeconds(timeout)).until(ExpectedConditions.elementToBeClickable(element));// Expectedcondition for the
																							
		element.click();

	}	
	
	public void checkIfPagesTrue(WebDriver driver1, WebElement element, int timeout, String text) throws InterruptedException {
		new WebDriverWait(driver1, Duration.ofSeconds(timeout)).until(ExpectedConditions.visibilityOf(element));// Expectedcondition for the
			
		assertTrue(element.getText().contains(text));
	}	
	
	
}