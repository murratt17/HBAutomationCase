package Helper;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SelectBrowser {
	
	static WebDriver wd;
	
	//chooses the browser
	public static WebDriver startBrowser(String url) {
		
		
	    JFrame frame = new JFrame("Select Browser");

		Object[] possibilities = {"chrome", "firefox"};
		
		//asks the user to choose the browser
		String s = (String)JOptionPane.showInputDialog(
		                    frame,
		                    "Select The Browser...\"",
		                    "Hepsiburada Browser Options",
		                    JOptionPane.PLAIN_MESSAGE,
		                    null,
		                    possibilities,
		                    "chrome");
		
		System.out.println(s + " secildi ");
		
		//creates ChromeDriver object
		if(s.equalsIgnoreCase("Chrome")){
		
			wd = new ChromeDriver();			
		
		}
		
		//creates FirefoxDriver object
		else if(s.equalsIgnoreCase("Firefox")){
			
			System.setProperty("webdriver.gecko.driver","src\\main\\resources\\geckodriver\\geckodriver.exe");
			wd = new FirefoxDriver();
		
		}
		
		//maximisizes
		wd.manage().window().maximize();
		wd.navigate().to(url);
		return wd;
	}

}
