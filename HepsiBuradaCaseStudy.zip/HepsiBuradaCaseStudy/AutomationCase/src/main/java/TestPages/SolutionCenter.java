package TestPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SolutionCenter {

	@FindBy(xpath = "//*[text() =  ' �r�nler orijinal midir? ']")
	WebElement lblProductOriginal;

	@FindBy(xpath = "//*[text() =  'Merak edilenler']")
	WebElement lblMerakEdilenler;

	@FindBy(xpath = "//*[text() = ' Farkl� bir konuda sorum var ']")
	WebElement txtDifferentTopic;

	@FindBy(xpath = "//*[text() = '�r�n bilgisi']")
	WebElement lblProductInfo;

	@FindBy(xpath = "//*[text() = ' �r�nler orijinal midir? ']")
	WebElement lblIsProductOriginal;

	@FindBy(xpath = "//*[text() = 'Beni aray�n']")
	WebElement btnBeniArayin;

	@FindBy(xpath = "//*[text()  = ' Sipari�im ile ilgili sorum var ']")
	WebElement aboutMyOrder;
	
	@FindBy(xpath = "(//*[contains(@class, 'orders-container')])[1]")
	WebElement myFirstOrder;
	
	
	
	
	
	
	final static String titleOfSolutionCenter = "��z�m Merkezi";

	WebDriver driver;

	public SolutionCenter(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getAboutMyOrder() {
		return aboutMyOrder;
	}
	
	public WebElement getMyFirstOrder() {
		return myFirstOrder;
	}
	
	
	
	public WebElement getDifferentTopic() {
		return txtDifferentTopic;
	}
	
	public WebElement getLblMerakEdilenler() {
		return lblMerakEdilenler;
	}
	public void clicklblProductInfo() {

		lblProductInfo.click();
	}

	public void clickLblIsProductOriginal() {
		lblIsProductOriginal.click();
	}

	public static String getTitleOfSolutionCenter() {
		return titleOfSolutionCenter;
	}

	public void clickDifferentTopic() {
		txtDifferentTopic.click();
	}


	public void clickMerakEdilenler() {
		lblMerakEdilenler.click();
	}

	
	public void clickProductOriginal() {
		lblProductOriginal.click();
	}

	public WebElement getLblProductInfo() {
		return lblProductInfo;
	}

	public WebElement getLblIsProductOriginial() {
		return lblIsProductOriginal;
	}

	public void clickBtnBeniArayin() {
		btnBeniArayin.click();
	}

	public WebElement getBtnBeniArayin() {
		return btnBeniArayin;
	}

}
