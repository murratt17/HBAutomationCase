package TestPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	@FindBy(id = "txtUserName")
	WebElement txttUsername;

	@FindBy(id = "txtPassword")
	WebElement txttPassw;

	@FindBy(id = "btnLogin")
	WebElement btnLogin;
	
	@FindBy(id = "btnEmailSelect")
	WebElement btnLogin2;
	
	
    final static String titleOfLoginPage = "�ye Giri� Sayfas� & �ye Ol - Hepsiburada";
    
	WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getBtnLogin() {
		return btnLogin;
	}
	
	public WebElement getBtnLogin2() {
		return btnLogin2;
	}

	public void setUsername(String username) {

		txttUsername.sendKeys(username);
	}
	
	public WebElement getUserName() {
		return txttUsername;
	}

	public void setPassword(String txtPassword) {

		txttPassw.sendKeys(txtPassword);
	}
	
	public WebElement getPassword() {
		return txttPassw;
	}

	public void clickBtnLogin() {
		btnLogin.click();
	}
	
	public void clickBtnLogin2() {
		btnLogin2.click();
	}
	
	public static String getTitleOfLoginPage() {
		return titleOfLoginPage;
	}

}
