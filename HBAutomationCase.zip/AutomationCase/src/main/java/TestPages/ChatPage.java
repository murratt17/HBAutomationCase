package TestPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ChatPage {
	
	String areProductsOriginal = "//div[@class='bottom-sheet-title']";
	
	@FindBy(xpath = "//*[text()  = 'Farkl� bir konuda sorum var']")
	WebElement questionAboutDifferenTopic;
	
	@FindBy(xpath = "//*[text()  = '�r�n bilgisi']")
	WebElement productInfo;
	
	@FindBy(xpath = "//*[text()  = ' �r�nler orijinal midir? ']")
	WebElement IsProductOriginal;
	
	@FindBy(xpath = "//div[@class='bottom-sheet-title']")
	WebElement AreProductsOriginial;
	
	@FindBy(xpath = "(//div[@class='container'])[2]")
	WebElement btnCallMe;
	
	
	@FindBy(xpath = "//div[@class='btn button-primary']")
	WebElement btnGonder;
	
	@FindBy(xpath = "(//div[@class='bottom-sheet-title'])[2] ")
	WebElement callRequest;
	
	@FindBy(xpath = "//div[@class='main-text']")
	WebElement mainText;
	
	@FindBy(xpath = "//div[@class='chat-desktop-title']")
	WebElement solutionCenterTitle;
	
	
	
	
	
	WebDriver driver;

	
	public ChatPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public String getXpatOfAreProductsOriginial() {
		return areProductsOriginal;
	}
	
	public WebElement getQuestionAboutDifferentTopic() {
		return questionAboutDifferenTopic;
	}
	
	public WebElement getSolutionCenterTitle() {
		return solutionCenterTitle;
	}
	
	public WebElement getMainText() {
		return mainText;
	}

	public WebElement getCallRequest() {
		return callRequest;
	}
	
	
	public WebElement getBtnGonder() {
		return btnGonder;
	}
	
	public WebElement getBtnCallMe() {
		return btnCallMe;
	}
	
	public WebElement getAreProductsOriginial() {
		return AreProductsOriginial;
	}
	
	public WebElement getProductInfo() {
		return productInfo;
	}
	
	public WebElement getIsProductOriginal() {
		return IsProductOriginal;
	}
	
	

}
